#  <#Title#>
# ARKA PLAN RESMİ
              Image("hesap")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
                .opacity(0.2)
             # LOGO RESMİ                
            Image("logo")
                .offset(y: -350)
                .frame(width: 135, height: 53)
                
                Text("Hesap Oluştur")
                    .font(.custom ("SP Pro Display Bold", size: 22))

# BUTON 
                    Text("Hesap Oluştur")
                        .bold()
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.purple)
                        .foregroundColor(.white)
                        .cornerRadius(25)
                        .padding(.horizontal)


#alikanliklar
.padding()
text""

