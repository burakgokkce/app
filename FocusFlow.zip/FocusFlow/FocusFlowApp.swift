//
//  FocusFlowApp.swift
//  FocusFlow
//
//  Created by Burak Gökce on 26.10.2024.
//

import SwiftUI

@main
struct FocusFlowApp: App {
    var body: some Scene {
        WindowGroup {
            WelcomeView()
        }
    }
}
